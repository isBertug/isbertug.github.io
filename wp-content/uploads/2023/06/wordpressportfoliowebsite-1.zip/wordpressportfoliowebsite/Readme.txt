Thank you for your recent purchase of "Trueman - CV Resume WordPress Theme".

--------------------------------------

Theme Documentation: https://bslthemes.gitbook.io/trueman-wp-doc/
Author: https://themeforest.net/user/bslthemes

--------------------------------------

Overview:

Trueman – CV Resume WordPress Theme is best suited for developer, designer, programmer, freelancer, artist, coder,
photography or any other digital professions. Modern and Creative theme design that will help you create a web presence.
Includes: Dark & Light versions, UI Live Switcher Mode, One Page & Multi Page, Transitions page animations,
Powerful Portfolio, Elementor Page Builder – No coding skills needed. You do not need to be a professional at
web development to successfully launch a high-end website. Creating a Resume/CV or personal website
with Trueman is effective way to promote yourself and showcase your works.

--------------------------------------

Sourse & Credits:

- ACF Pro
- Elementor
- Bootstrap
- Font Awesome icons
- Magnific Popup
- imagesLoaded
- Isotope
- Swiper
- Unsplash
- Shutterstock

--------------------------------------

IMPORTANT: Images used in the Preview demo are not included in the downloaded package.
