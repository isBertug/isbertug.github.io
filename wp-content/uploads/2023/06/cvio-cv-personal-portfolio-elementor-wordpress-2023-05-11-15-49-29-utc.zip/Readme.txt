Thank you for your recent purchase of "Cvio - CV Resume WordPress Theme".

--------------------------------------

Theme Documentation: https://bslthemes.gitbook.io/cvio-wp-doc/
Author: https://themeforest.net/user/bslthemes

--------------------------------------


Overview:

Cvio – Resume WordPress Theme best suited for developers, designers, programmers, freelancers, writers, musician, photographers or any other professions. Modern and clean theme with a trendy dark design that will help you create a web presence. Includes: Different layouts, Dark & Light mode, Unlimited color, RTL support, One & Multi page, One Click Demo Import, WooCommerce Support, Transitions page animations, ACF Pro and Elementor – No coding skills needed, creating online resume and CV websites should no longer be a difficult. You do not need to be a professional at web development to successfully launch a high-end website. Creating a Resume/CV or personal website with Cvio is effective way to promote yourself and showcase your works.

--------------------------------------


Features:

Elementor Drag & Drop Page Builder
Multi and One Page
8+ Home Page Variants
Compatible with WordPress 5.8
WooCommerce Support
Dark & Light Mode
RTL Support
6+ Background Options (Default, Image, Video, Gradient, Color, Slideshow)
6+ Lightbox Portfolio Variants: Image, Gallery, Media, Iframe (YouTube, Vimeo), Audio (SoundCloud), Link
ACF Pro Plugin Included (Save $25)
One Click Demo Import
Awesome Portfolio with Isotope Filters
Skills with Percent & Dotted Bar, Circles, Knowledge
Resume On Timeline
Testimonials Carousel
Team Carousel
Pricing Tables
Contact Form 7 Plugin
Unlimited Colors
Fully Responsive
Minimal and Clean
Fully Customize
Cross Browser
ACF flexible content
Import Demo Data
Blog Page & Blog Details Page
Clean code
Widgets ready
Localization Support (Included .pot file)
Child themes support
Fonts Icons
Google Fonts
24/7 Support
Regular Updates
Documentation Included
and more features coming soon!

--------------------------------------


Sourse & Credits:

- Elementor
- ACF Pro
- Isotope
- jQuery Validation Plugin
- Magnific Popup
- Unsplash
- FontAwesome
- Jarallax
- Animate.css

--------------------------------------


IMPORTANT: Images used in the Preview demo are not included in the downloaded package.
