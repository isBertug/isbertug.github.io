<?php
/**
 * The template for displaying all posts
 *
 * @package trueman
 */

get_template_part( 'index' );

?>
