<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package trueman
 */

get_header();
?>

<?php get_template_part( 'template-parts/archive-list' ); ?>

<?php
get_footer();
